#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <time.h>


#define HASH_SIZE 9973
#define MAX_ID 50017

std :: ifstream inUSNames("us_names.txt");
std :: ifstream inNames("names.txt");
std :: ofstream outNames("names.txt");
std :: ifstream in("input.txt");
std :: ofstream out("output.txt");
std :: ofstream dout("demo.txt");

struct entry{
    int id{};
    std :: string name;
} entries[ HASH_SIZE ];

int table[ HASH_SIZE ];
int searchOps;
int avgEffortFound, maxEffortFound, avgEffortNotFound, maxEffortNotFound;
int finalAvgEffortFound, finalMaxEffortFound, finalAvgEffortNotFound, finalMaxEffortNotFound;
const int no_tests = 5;
float a[] = { 0.8, 0.85, 0.9, 0.95, 0.99 };
std :: set< int > s;

void generateNames( int maxNames );
void createEntries( int entriesSize );
void printEntries( int entriesSize );

void initTable();
int hash( int id, int tableSize );
void insertTable( int entryIndex, int tableSize, bool isOutputEnabled = true );
void deleteTable( int entryIndex, int tableSize, bool isOutputEnabled = true );
void searchTable( int entryIndex, int tableSize, bool isOutputEnabled = true );
void printTable( int tableSize, int entriesSize );

int getIndexById( int id, int entriesSize );
void evaluateSearch( float alpha, int entriesSize );
void calculateEffortForAlpha( float alpha );
void printEfforts( float alpha, bool doDivision = true );

void demo();




int main() {
    initTable();
    generateNames( HASH_SIZE );

    demo();

    createEntries( HASH_SIZE );

    for( int i = 0; i < 5; ++ i ) {
        calculateEffortForAlpha( a[ i ] );
        printEfforts( a[ i ], false );
    }

    return 0;
}

void calculateEffortForAlpha( float alpha ) {
    finalMaxEffortFound = 0;
    finalAvgEffortFound = 0;
    finalMaxEffortNotFound = 0;
    finalAvgEffortNotFound = 0;

    avgEffortFound = 0;
    maxEffortFound = 0;
    avgEffortNotFound = 0;
    maxEffortNotFound = 0;

    evaluateSearch( alpha, HASH_SIZE);

    finalAvgEffortFound += avgEffortFound;
    finalMaxEffortFound += maxEffortFound;
    finalAvgEffortNotFound += avgEffortNotFound;
    finalMaxEffortNotFound += maxEffortNotFound;
}

void printEfforts( float alpha, bool doDivision ) {
    if( doDivision ) {
        finalAvgEffortFound /= 5;
        finalMaxEffortFound /= 5;
        finalAvgEffortNotFound /= 5;
        finalMaxEffortNotFound /= 5;
    }

    out << "Effort results for alpha equal to: " << alpha << '\n';
    out << "Avg Effort Found: " << finalAvgEffortFound << '\n';
    out << "Max Effort Found: " << finalMaxEffortFound << '\n';
    out << "Avg Effort Not Found: " << finalAvgEffortNotFound << '\n';
    out << "Max Effort Not Found: " << finalMaxEffortNotFound << '\n';
    out << '\n';
}

void evaluateSearch( float alpha, int entriesSize ) {
    s.clear();
    int alphaSize = int( alpha * float( entriesSize ) );
    const int inserted = 1500, notInserted = 1500;

    createEntries( alphaSize );

    for( int i = 0; i < inserted; ++ i ) {
        searchOps = 0;

        int entryIndex = rand() % alphaSize;

        while( s.find( entryIndex ) != s.end() )
            entryIndex = rand() % alphaSize;

        s.insert( entryIndex );

        insertTable( entryIndex, HASH_SIZE, false );
        searchTable( entryIndex, HASH_SIZE, false );
        avgEffortFound += searchOps;
        if( searchOps > maxEffortFound )
            maxEffortFound = searchOps;
    }
    for( int i = 0; i < notInserted; ++ i ){
        searchOps = 0;

        int entryIndex = rand() % alphaSize;

        while( s.find( entryIndex ) != s.end() )
            entryIndex = rand() % alphaSize;

        s.insert( entryIndex );

        searchTable( entryIndex, HASH_SIZE, false );
        avgEffortNotFound += searchOps;
        if( searchOps > maxEffortNotFound )
            maxEffortNotFound = searchOps;
    }

    avgEffortFound /= inserted;
    avgEffortNotFound /= notInserted;
}

/// Pentru alegere random, punem id-ul a 1500 elemente random inserate in hash intr-un set
/// si cand cautam 1500 elemente neinserate le luam random din entries si verificam sa nu
/// se afle deja in set ( set.find() == set.end() )

void searchTable( int entryIndex, int tableSize, bool isOutputEnabled ) {
    int id = entries[ entryIndex ].id;
    int position = hash( id, tableSize );

    if( id == table[ position ] ) {
        if( isOutputEnabled )
            dout << "Found " << entries[ entryIndex ].name << " at position " << position << '\n';
        ++ searchOps;
        return;
    }

    for ( int j = 1; j < tableSize; ++ j ) {
        int t = ( position + j * j ) % tableSize;
        ++ searchOps;
        if( id == table[ t ] ) {
            if( isOutputEnabled )
                dout << "Found " << entries[ entryIndex ].name << " at position " << position << '\n';
            return;
        }
    }

    if( isOutputEnabled )
        dout << "Didn't find " << entries[ entryIndex ].name << " in the hash table\n";
}

void insertTable( int entryIndex, int tableSize, bool isOutputEnabled ) {
    int id = entries[ entryIndex ].id;
    int position = hash( id, tableSize );
    bool inserted = false;

    if( isOutputEnabled )
        dout << "Will insert " << entries[ entryIndex ].name << " of id " << entries[ entryIndex ].id << " at position " << position <<'\n';

    if( table[ position ] == -1 ) {
        table[ position ] = id;
        inserted = true;
    }
    else {
        for ( int j = 1; j < tableSize; ++ j ) {
            int t = ( position + j * j ) % tableSize;

            if( table[ t ] == -1 ) {
                table[ t ] = id;
                inserted = true;
                if( isOutputEnabled )
                    std :: cout << entries[ entryIndex ].name << " " << id << " " << t << '\n';
                break;
            }
        }
    }
    if( !inserted && isOutputEnabled )
        dout << "Couldn't insert " << entries[ entryIndex ].name << '\n';
}

void demo() {
    const int entriesSize = 10, tableSize = 5;

    std :: string firstName, lastName, name, whiteSpace;
    for( int i = 0; i < entriesSize; ++ i ) {
        entries[ i ].id = rand() % MAX_ID;

        in >> firstName >> lastName;
        name = firstName + ' ' + lastName;
        entries[ i ].name = name;
    }

    dout << "ENTRIES ARE:\n";
    printEntries( 10 );
    dout << '\n';

    for( int i = 0; i < entriesSize; ++ i ) {
        if( i == 3 ) {
            deleteTable( 1, tableSize );
            dout << "Deleting Olivia Baker:\n";
            printTable( tableSize, entriesSize );
            dout << '\n';
        }

        dout << "Inserting entry " << i << ":\n";
        insertTable( i, tableSize );
        printTable( tableSize, entriesSize );
        dout << '\n';
    }

    deleteTable( 0, tableSize );
    deleteTable( 7, tableSize );

    dout << "Table after deleting Aiden Evans:\n";
    printTable( tableSize, entriesSize );

    dout << '\n';

    searchTable( 0, tableSize );
    searchTable( 3, tableSize );
    searchTable( 6, tableSize );
}

void deleteTable( int entryIndex, int tableSize, bool isOutputEnabled ) {
    int id = entries[ entryIndex ].id;
    int position = hash( id, tableSize );

    if( id == table[ position ] ) {
        table[ position ] = -1;
        return;
    }

    for ( int j = 1; j < tableSize; ++ j ) {
        int t = ( position + j * j ) % tableSize;
        if( id == table[ t ] ) {
            table[ position ] = -1;
            return;
        }
    }

    if( isOutputEnabled )
        dout << "Didn't find " << entries[ entryIndex ].name << " in the hash table\n";
}

int hash( int id, int tableSize ) {
    return id % tableSize;
}

void generateNames( int maxNames ) {
    std :: string name;
    int noNames = 0;
    for( int i = 8; i < 88800; ++ i ) {
        inUSNames >> name;

        if( i % 8 == 0 )
            outNames << name << ' ';
        else if( i % 8 == 1 ) {
            outNames << name << '\n';
            ++ noNames;
        }

        if( noNames >= maxNames )
            return;
    }
}

void createEntries( int entriesSize ) {
    std :: string firstName, lastName, name, whiteSpace;

    for( int i = 0; i < entriesSize; ++ i ) {
        entries[ i ].id = rand() % MAX_ID;

        inNames >> firstName >> lastName;
        name = firstName + ' ' + lastName;
        entries[ i ].name = name;
    }
}

void printEntries( int entriesSize ) {
    for( int i = 0; i < entriesSize; ++ i )
        dout << entries[ i ].id << ' ' << entries[ i ].name << '\n';
}

void initTable() {
    for( int & i : table )
        i = -1;
}

int getIndexById( int id, int entriesSize ) {
    for( int i = 0; i < entriesSize; ++ i )
        if( entries[ i ].id == id )
            return i;
    return -1;
}

void printTable( int tableSize, int entriesSize ) {
    for( int i = 0; i < tableSize; ++ i ) {
        if( table[ i ] == - 1 )
            dout << "EMPTY\n";
        else
            dout << entries[ getIndexById( table[ i ], entriesSize ) ].name << '\n';
    }
}